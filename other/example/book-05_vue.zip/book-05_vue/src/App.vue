<script setup>
import Book from './components/Book.vue'
</script>

<template>
  <Book />
</template>

<style scoped>
</style>
