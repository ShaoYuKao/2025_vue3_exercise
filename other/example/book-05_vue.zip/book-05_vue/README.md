
## 整合說明

- 將 `book-05` 專案 `images` 資料夾，搬移到 `book-05_vue` 專案 `src\assets` 資料夾裡。

![](./images/圖片1.png)

- 將 `book-05` 專案 `18_215-magic-wand-custom.html` 檔案裡， `<body>`, `<script type="module">` 程式碼，轉換到 `book-05_vue` 專案 `Book.vue` Component。

![](./images/圖片2.png)

- `book-05` 專案裡，`CSS3DRenderer.js`, `TrackballControls.js`, `tween.module.js` 三個套件，在 `book-05_vue` 專案，則使用 npm 方式安裝套件。

```bash
npm i three@0.172.0 @tweenjs/tween.js@23.1.1 @three-ts/orbit-controls@1.4.7
```

![](./images/圖片3.png)

- `book-05` 專案 `18_215-magic-wand-custom.html` 檔案裡 `<style>` 樣式，轉換到 `book-05_vue` 專案，修改的檔案有 `src\components\Book.vue`, `src\style.css`。

![](./images/圖片4.png)

![](./images/圖片5.png)

## 在 Vite + Vue 3 專案中，**圖片資源放在 `public/images` 或 `src/assets/images` 的差異如下**：

---

## 1. **放在 `public/images`**
📂 **對應專案目錄**
```
public/
└── images/
    ├── logo.png
    ├── banner.jpg
```

📌 **特性**
- **不會經過 Vite 處理**，檔案會直接保留原始名稱與路徑。
- 可以使用**絕對 URL** 引用，如：
  ```html
  <img src="/images/logo.png" alt="Logo">
  ```
- 適合用於**靜態資源**，例如：
  - **Favicons** (網站圖示)
  - **SEO 相關圖片** (如 Open Graph images)
  - **不需要經過 Webpack/Vite 處理的外部圖片**
- 不會包含在 `dist/assets` 內，而是直接複製到 `dist` 目錄。

📌 **優缺點**
✅ 優點：
- 直接提供靜態資源，避免額外處理。
- 適用於需要**公開 URL 的資源** (如 CDN 引用)。

❌ 缺點：
- **無法使用 Vite 的資源優化**（如 hash 版本管理）。
- **不能使用 `import` 語法** 引入圖片。
- **若圖片檔案名稱變更，需手動修改所有引用的地方**。

---

## 2. **放在 `src/assets/images`**
📂 **對應專案目錄**
```
src/assets/
└── images/
    ├── logo.png
    ├── banner.jpg
```

📌 **特性**
- **會經過 Vite 處理**，如壓縮、哈希化（版本控制）。
- 可以用 `import` 引入：
  ```vue
  <script setup>
  import logo from '@/assets/images/logo.png';
  </script>

  <template>
    <img :src="logo" alt="Logo">
  </template>
  ```
- 會被 Vite **打包到 `dist/assets` 目錄**，並自動加上 hash，如：
  ```
  dist/assets/logo-abc123.png
  ```

📌 **優缺點**
✅ 優點：
- **可享受 Vite 內建優化**（如 tree shaking、壓縮）。
- **可用 `import` 或 `@/assets/images/logo.png` 方式動態載入**。
- **修改圖片時不需要手動更新引用**，因為 Vite 會自動管理 hash。

❌ 缺點：
- **不能直接透過 URL (`/images/logo.png`) 引用**，需要 `import` 或 `@/` 別名。
- **大型圖片會增加打包時間**，不適合存放大量靜態圖片。

---

## 3. **何時用 `public/images`，何時用 `src/assets/images`？**
📌 **使用 `public/images` 的時機**
- **圖片不需要被 Vite 處理**（例如 favicon、社群分享圖）。
- **第三方工具會直接使用圖片 URL**（如 `<meta property="og:image" content="/images/banner.jpg">`）。
- **需要保證 URL 固定**（如外部 API 會引用這些圖片）。

📌 **使用 `src/assets/images` 的時機**
- **圖片會被 Vue 組件引用**，如 `<img>`、CSS 背景圖片等。
- **希望讓 Vite 自動優化與管理版本**，避免快取問題。
- **需要用 `import` 動態載入圖片**。

---

## 4. **最佳實踐**
- **專案 Logo, Favicon, SEO 圖片 → `public/images`**
- **元件內使用的圖片（如 UI 按鈕、背景圖）→ `src/assets/images`**
- **API 回應的圖片 (例如 User Avatar) → 存在伺服器或 CDN，不存於專案內**

這樣能夠達到**最佳效能與維護性**！ 🚀
